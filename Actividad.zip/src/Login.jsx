import { useState } from "react";
const IconUser = () => (
  <svg width="16" height="16" fill="none" stroke="#9ca3af" strokeWidth="2" viewBox="0 0 24 24"
    style={{ position: "absolute", left: 11, top: "50%", transform: "translateY(-50%)" }}>
    <circle cx="12" cy="8" r="4" />
    <path strokeLinecap="round" d="M4 20c0-4 3.6-7 8-7s8 3 8 7" />
  </svg>
);

const IconLock = () => (
  <svg width="16" height="16" fill="none" stroke="#9ca3af" strokeWidth="2" viewBox="0 0 24 24"
    style={{ position: "absolute", left: 11, top: "50%", transform: "translateY(-50%)" }}>
    <rect x="5" y="11" width="14" height="10" rx="2" />
    <path strokeLinecap="round" d="M8 11V7a4 4 0 018 0v4" />
  </svg>
);

const IconBox = () => (
  <svg width="36" height="36" fill="none" stroke="#63b3ff" strokeWidth="1.8" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round"
      d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
  </svg>
);

const IconEye = ({ visible }) => (
  <svg width="16" height="16" fill="none" stroke="#9ca3af" strokeWidth="2" viewBox="0 0 24 24">
    {visible ? (
      <>
        <path strokeLinecap="round" d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
        <circle cx="12" cy="12" r="3" />
      </>
    ) : (
      <>
        <path strokeLinecap="round" d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24" />
        <line x1="1" y1="1" x2="23" y2="23" strokeLinecap="round" />
      </>
    )}
  </svg>
);
const ROLES = ["Administrador", "Cajero", "Bodeguero"];

export default function Login() {
  const [rolActivo, setRolActivo] = useState("Administrador");
  const [usuario, setUsuario] = useState("");
  const [password, setPassword] = useState("");
  const [mostrarPass, setMostrarPass] = useState(false);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = () => {
    setError("");
    if (!usuario || !password) {
      setError("Por favor completa todos los campos.");
      return;
    }
    setCargando(true);
    // Simula llamada a API
    setTimeout(() => {
      setCargando(false);
      // Aquí iría la lógica real de autenticación
      alert(`Iniciando sesión como ${rolActivo}: ${usuario}`);
    }, 1200);
  };

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        {/* ── Panel izquierdo (marca) ── */}
        <div style={styles.leftPanel}>
          <div style={styles.iconWrap}>
            <IconBox />
          </div>
          <p style={styles.brandSub}>Sistema</p>
          <h1 style={styles.brandTitle}>SuperMercado</h1>
          <p style={styles.brandDesc}>Gestión integral de inventario y ventas para tu supermercado</p>
          <div style={styles.brandDivider} />
          <p style={styles.brandVersion}>v1.0.0 — 2026</p>
        </div>

        {/* ── Panel derecho (formulario) ── */}
        <div style={styles.rightPanel}>
          <h2 style={styles.formTitle}>Bienvenido</h2>
          <p style={styles.formSub}>Ingresa tus credenciales para continuar</p>

          {/* Selector de rol */}
          <label style={styles.fieldLabel}>Tipo de usuario</label>
          <div style={styles.roleRow}>
            {ROLES.map((rol) => (
              <button
                key={rol}
                onClick={() => setRolActivo(rol)}
                style={{
                  ...styles.roleBtn,
                  ...(rolActivo === rol ? styles.roleBtnActive : {}),
                }}
              >
                {rol}
              </button>
            ))}
          </div>

          {/* Campo usuario */}
          <div style={styles.fieldGroup}>
            <label style={styles.fieldLabel}>Usuario</label>
            <div style={styles.inputWrap}>
              <IconUser />
              <input
                type="text"
                placeholder="tu.usuario@supermarket.com"
                value={usuario}
                onChange={(e) => setUsuario(e.target.value)}
                style={styles.input}
              />
            </div>
          </div>

          {/* Campo contraseña */}
          <div style={styles.fieldGroup}>
            <label style={styles.fieldLabel}>Contraseña</label>
            <div style={styles.inputWrap}>
              <IconLock />
              <input
                type={mostrarPass ? "text" : "password"}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                style={{ ...styles.input, paddingRight: 36 }}
                onKeyDown={(e) => e.key === "Enter" && handleLogin()}
              />
              <button
                onClick={() => setMostrarPass(!mostrarPass)}
                style={styles.eyeBtn}
                aria-label="Mostrar/ocultar contraseña"
              >
                <IconEye visible={mostrarPass} />
              </button>
            </div>
          </div>

          {/* Error */}
          {error && (
            <div style={styles.errorMsg}>
              <span>⚠</span> {error}
            </div>
          )}

          {/* Olvidé contraseña */}
          <div style={styles.forgotRow}>
            <button onClick={() => {}} style={styles.forgotLink}>¿Olvidaste tu contraseña?</button>
          </div>

          {/* Botón */}
          <button
            onClick={handleLogin}
            disabled={cargando}
            style={{ ...styles.btnLogin, opacity: cargando ? 0.7 : 1 }}
          >
            {cargando ? "Verificando..." : "Iniciar sesión"}
          </button>
        </div>
      </div>
    </div>
  );
}
const styles = {
  page: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    minHeight: "100vh",
    background: "#f0f4f8",
    fontFamily: "'Segoe UI', sans-serif",
    padding: 20,
  },
  card: {
    display: "flex",
    borderRadius: 14,
    overflow: "hidden",
    boxShadow: "0 4px 24px rgba(0,0,0,0.10)",
    maxWidth: 780,
    width: "100%",
  },
  leftPanel: {
    background: "#1a2332",
    flex: 1,
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    padding: "40px 30px",
    color: "#fff",
  },
  iconWrap: {
    width: 80,
    height: 80,
    background: "#1e3a5f",
    borderRadius: "50%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 20,
    border: "2px solid #2d5a8e",
  },
  brandSub: { fontSize: 11, color: "#7a9abe", textTransform: "uppercase", letterSpacing: 2, marginBottom: 6 },
  brandTitle: { fontSize: 26, fontWeight: 700, color: "#e8f0fe", marginBottom: 14 },
  brandDesc: { fontSize: 12, color: "#6a8caa", textAlign: "center", lineHeight: 1.6, maxWidth: 180 },
  brandDivider: { width: 40, height: 1, background: "#2d3f55", margin: "20px 0" },
  brandVersion: { fontSize: 10, color: "#3d5470" },
  rightPanel: {
    flex: 1,
    background: "#fff",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    padding: "40px 36px",
  },
  formTitle: { fontSize: 20, fontWeight: 700, color: "#111827", marginBottom: 4 },
  formSub: { fontSize: 12, color: "#6b7280", marginBottom: 24 },
  fieldLabel: {
    display: "block",
    fontSize: 11,
    fontWeight: 600,
    color: "#374151",
    textTransform: "uppercase",
    letterSpacing: 0.8,
    marginBottom: 6,
  },
  roleRow: { display: "flex", gap: 8, marginBottom: 20 },
  roleBtn: {
    flex: 1,
    padding: "7px 0",
    fontSize: 11,
    border: "1px solid #d1d5db",
    borderRadius: 6,
    cursor: "pointer",
    background: "#f9fafb",
    color: "#6b7280",
    fontWeight: 500,
    transition: "all 0.15s",
  },
  roleBtnActive: {
    background: "#eff6ff",
    borderColor: "#3b82f6",
    color: "#1d4ed8",
  },
  fieldGroup: { marginBottom: 14 },
  inputWrap: { position: "relative" },
  input: {
    width: "100%",
    padding: "10px 12px 10px 38px",
    border: "1px solid #d1d5db",
    borderRadius: 7,
    fontSize: 13,
    color: "#111827",
    background: "#f9fafb",
    outline: "none",
    boxSizing: "border-box",
  },
  eyeBtn: {
    position: "absolute",
    right: 10,
    top: "50%",
    transform: "translateY(-50%)",
    background: "none",
    border: "none",
    cursor: "pointer",
    padding: 2,
    display: "flex",
    alignItems: "center",
  },
  errorMsg: {
    background: "#fef2f2",
    border: "1px solid #fecaca",
    borderRadius: 7,
    padding: "8px 12px",
    fontSize: 12,
    color: "#b91c1c",
    marginBottom: 10,
    display: "flex",
    alignItems: "center",
    gap: 6,
  },
  forgotRow: { textAlign: "right", marginBottom: 16 },
  forgotLink: { fontSize: 11, color: "#3b82f6", textDecoration: "none" },
  btnLogin: {
    width: "100%",
    padding: 11,
    background: "#1a2332",
    color: "#fff",
    border: "none",
    borderRadius: 7,
    fontSize: 13,
    fontWeight: 600,
    cursor: "pointer",
    letterSpacing: 0.5,
    transition: "background 0.2s",
  },
};
