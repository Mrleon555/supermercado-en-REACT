import { useState, useEffect } from "react";

const IconError = () => (
  <svg width="20" height="20" fill="none" stroke="#ef4444" strokeWidth="2" viewBox="0 0 24 24" style={{ flexShrink: 0 }}>
    <circle cx="12" cy="12" r="10" />
    <line x1="12" y1="8" x2="12" y2="12" strokeLinecap="round" />
    <circle cx="12" cy="16" r="0.5" fill="#ef4444" />
  </svg>
);
const IconWarning = () => (
  <svg width="20" height="20" fill="none" stroke="#f59e0b" strokeWidth="2" viewBox="0 0 24 24" style={{ flexShrink: 0 }}>
    <path strokeLinecap="round" strokeLinejoin="round"
      d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
  </svg>
);
const IconSuccess = () => (
  <svg width="20" height="20" fill="none" stroke="#22c55e" strokeWidth="2" viewBox="0 0 24 24" style={{ flexShrink: 0 }}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);
const IconInfo = () => (
  <svg width="20" height="20" fill="none" stroke="#3b82f6" strokeWidth="2" viewBox="0 0 24 24" style={{ flexShrink: 0 }}>
    <circle cx="12" cy="12" r="10" />
    <line x1="12" y1="16" x2="12" y2="12" strokeLinecap="round" />
    <circle cx="12" cy="8" r="0.5" fill="#3b82f6" />
  </svg>
);
const NOTIF_CONFIG = {
  error:   { bg: "#fef2f2", border: "#ef4444", titleColor: "#991b1b", msgColor: "#b91c1c", Icon: IconError },
  warning: { bg: "#fffbeb", border: "#f59e0b", titleColor: "#92400e", msgColor: "#b45309", Icon: IconWarning },
  success: { bg: "#f0fdf4", border: "#22c55e", titleColor: "#166534", msgColor: "#15803d", Icon: IconSuccess },
  info:    { bg: "#eff6ff", border: "#3b82f6", titleColor: "#1e40af", msgColor: "#1d4ed8", Icon: IconInfo },
};

function Notificacion({ id, tipo, titulo, mensaje, onClose, autoCerrar = false, duracion = 4000 }) {
  const config = NOTIF_CONFIG[tipo] || NOTIF_CONFIG.info;
  const { bg, border, titleColor, msgColor, Icon } = config;

  useEffect(() => {
    if (!autoCerrar) return;
    const timer = setTimeout(() => onClose(id), duracion);
    return () => clearTimeout(timer);
  }, [id, autoCerrar, duracion, onClose]);

  return (
    <div
      style={{
        ...styles.notif,
        background: bg,
        borderLeftColor: border,
      }}
    >
      <Icon />
      <div style={styles.notifBody}>
        <p style={{ ...styles.notifTitle, color: titleColor }}>{titulo}</p>
        <p style={{ ...styles.notifMsg, color: msgColor }}>{mensaje}</p>
      </div>
      <button onClick={() => onClose(id)} style={styles.closeBtn} aria-label="Cerrar">×</button>
    </div>
  );
}

function FormularioProducto({ onAgregar }) {
  const [nombre, setNombre] = useState("");
  const [stock, setStock] = useState("");
  const [codigo, setCodigo] = useState("");
  const [categoria, setCategoria] = useState("Lácteos");
  const [errores, setErrores] = useState({});

  const categorias = ["Lácteos", "Carnes", "Bebidas", "Aseo", "Panadería", "Frutas y Verduras"];

  const validar = () => {
    const nuevosErrores = {};
    if (!nombre.trim()) nuevosErrores.nombre = "El nombre del producto es obligatorio";
    if (!stock || Number(stock) < 1) nuevosErrores.stock = "Ingresa una cantidad válida (mínimo 1)";
    setErrores(nuevosErrores);
    return Object.keys(nuevosErrores).length === 0;
  };

  const handleGuardar = () => {
    if (validar()) {
      onAgregar({ tipo: "success", titulo: "Producto guardado correctamente",
        mensaje: `"${nombre}" fue agregado al inventario con ${stock} unidades.${codigo ? ` Código: ${codigo}` : ""}` });
      setNombre(""); setStock(""); setCodigo(""); setErrores({});
    } else {
      onAgregar({ tipo: "error", titulo: "Error al guardar el producto",
        mensaje: "Completa los campos obligatorios marcados en rojo antes de continuar." });
    }
  };

  const fieldStyle = (campo) => ({
    ...styles.input,
    ...(errores[campo] ? styles.inputError : {}),
  });

  return (
    <div style={styles.formCard}>
      <p style={styles.formCardTitle}>
        <svg width="15" height="15" fill="none" stroke="#374151" strokeWidth="2" viewBox="0 0 24 24" style={{ verticalAlign: "middle", marginRight: 6 }}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
        </svg>
        Agregar producto al inventario
      </p>

      <div style={styles.formGrid}>
        <div style={styles.fieldGroup}>
          <label style={styles.fieldLabel}>Nombre del producto *</label>
          <input
            type="text"
            placeholder="Ej: Leche entera 1L"
            value={nombre}
            onChange={(e) => { setNombre(e.target.value); setErrores((prev) => ({ ...prev, nombre: "" })); }}
            style={fieldStyle("nombre")}
          />
          {errores.nombre && <p style={styles.fieldError}>{errores.nombre}</p>}
        </div>

        <div style={styles.fieldGroup}>
          <label style={styles.fieldLabel}>Código de barras</label>
          <input
            type="text"
            placeholder="7702034001234"
            value={codigo}
            onChange={(e) => setCodigo(e.target.value)}
            style={styles.input}
          />
        </div>

        <div style={styles.fieldGroup}>
          <label style={styles.fieldLabel}>Stock inicial *</label>
          <input
            type="number"
            placeholder="0"
            value={stock}
            onChange={(e) => { setStock(e.target.value); setErrores((prev) => ({ ...prev, stock: "" })); }}
            style={fieldStyle("stock")}
          />
          {errores.stock && <p style={styles.fieldError}>{errores.stock}</p>}
        </div>

        <div style={styles.fieldGroup}>
          <label style={styles.fieldLabel}>Categoría</label>
          <select value={categoria} onChange={(e) => setCategoria(e.target.value)} style={styles.input}>
            {categorias.map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
      </div>

      <div style={styles.btnRow}>
        <button onClick={() => { setNombre(""); setStock(""); setCodigo(""); setErrores({}); }} style={styles.btnCancel}>
          Cancelar
        </button>
        <button onClick={handleGuardar} style={styles.btnSave}>
          Guardar producto
        </button>
      </div>
    </div>
  );
}

export function useNotificaciones() {
  const [notificaciones, setNotificaciones] = useState([]);

  const agregar = ({ tipo, titulo, mensaje, autoCerrar = false, duracion = 4000 }) => {
    const id = Date.now();
    setNotificaciones((prev) => [...prev, { id, tipo, titulo, mensaje, autoCerrar, duracion }]);
    return id;
  };

  const cerrar = (id) => {
    setNotificaciones((prev) => prev.filter((n) => n.id !== id));
  };

  return { notificaciones, agregar, cerrar };
}

export default function NotificacionesDemo() {
  const { notificaciones, agregar, cerrar } = useNotificaciones();

  const ejemplos = [
    { tipo: "error",   titulo: "Error al guardar",      mensaje: "No se pudo conectar con el servidor. Intenta de nuevo." },
    { tipo: "warning", titulo: "Stock bajo",             mensaje: 'El producto "Arroz Diana 500g" tiene solo 3 unidades.' },
    { tipo: "success", titulo: "Guardado correctamente", mensaje: "El producto fue registrado exitosamente en el inventario." },
    { tipo: "info",    titulo: "Actualización disponible", mensaje: "Hay una nueva versión del sistema. Recarga la página." },
  ];

  const handleAgregar = ({ tipo, titulo, mensaje }) => {
    agregar({ tipo, titulo, mensaje, autoCerrar: tipo === "success", duracion: 4000 });
  };

  return (
    <div style={styles.page}>
      <div style={styles.header}>
        <p style={styles.headerSub}>Sistema SuperMercado</p>
        <h1 style={styles.headerTitle}>Notificaciones</h1>
      </div>

      {/* Formulario interactivo */}
      <FormularioProducto onAgregar={handleAgregar} />

      {/* Botones para disparar cada tipo de notificación */}
      <div style={styles.section}>
        <p style={styles.sectionLabel}>Disparar notificación de ejemplo</p>
        <div style={styles.btnEjemplosRow}>
          {ejemplos.map((ej) => (
            <button
              key={ej.tipo}
              onClick={() => agregar({ ...ej, autoCerrar: ej.tipo === "success" })}
              style={{ ...styles.btnEjemplo, borderColor: NOTIF_CONFIG[ej.tipo].border,
                color: NOTIF_CONFIG[ej.tipo].titleColor }}
            >
              {{ error: "Error", warning: "Advertencia", success: "Guardado", info: "Información" }[ej.tipo]}
            </button>
          ))}
        </div>
      </div>

      {/* Stack de notificaciones activas */}
      {notificaciones.length > 0 && (
        <div style={styles.section}>
          <p style={styles.sectionLabel}>Notificaciones activas ({notificaciones.length})</p>
          <div style={styles.notifStack}>
            {notificaciones.map((n) => (
              <Notificacion key={n.id} {...n} onClose={cerrar} />
            ))}
          </div>
        </div>
      )}

      {notificaciones.length === 0 && (
        <p style={styles.emptyMsg}>Sin notificaciones activas. Interactúa con el formulario o los botones.</p>
      )}
    </div>
  );
}

const styles = {
  page: { background: "#f0f4f8", minHeight: "100vh", padding: 24, fontFamily: "'Segoe UI', sans-serif", fontSize: 13 },
  header: { marginBottom: 20 },
  headerSub: { fontSize: 11, color: "#9ca3af", textTransform: "uppercase", letterSpacing: 1 },
  headerTitle: { fontSize: 22, fontWeight: 700, color: "#111827" },
  formCard: { background: "#fff", borderRadius: 10, border: "0.5px solid #e5e7eb", padding: "20px 22px", marginBottom: 16 },
  formCardTitle: { fontSize: 13, fontWeight: 600, color: "#111827", marginBottom: 16 },
  formGrid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 16 },
  fieldGroup: { display: "flex", flexDirection: "column" },
  fieldLabel: { fontSize: 10, fontWeight: 600, color: "#6b7280", textTransform: "uppercase", letterSpacing: 0.7, marginBottom: 5 },
  input: { padding: "8px 10px", border: "1px solid #d1d5db", borderRadius: 6, fontSize: 12, color: "#374151", background: "#f9fafb", outline: "none" },
  inputError: { borderColor: "#ef4444", background: "#fff5f5" },
  fieldError: { fontSize: 10, color: "#ef4444", marginTop: 3 },
  btnRow: { display: "flex", gap: 10, justifyContent: "flex-end" },
  btnCancel: { padding: "8px 18px", background: "#fff", border: "1px solid #d1d5db", borderRadius: 6, fontSize: 12, color: "#6b7280", cursor: "pointer" },
  btnSave: { padding: "8px 20px", background: "#1a2332", border: "none", borderRadius: 6, fontSize: 12, color: "#fff", cursor: "pointer", fontWeight: 600 },
  section: { marginBottom: 16 },
  sectionLabel: { fontSize: 11, color: "#9ca3af", fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.8, marginBottom: 8 },
  btnEjemplosRow: { display: "flex", gap: 8, flexWrap: "wrap" },
  btnEjemplo: { padding: "7px 16px", background: "#fff", border: "1.5px solid", borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: "pointer" },
  notifStack: { display: "flex", flexDirection: "column", gap: 10 },
  notif: { display: "flex", alignItems: "flex-start", gap: 12, padding: "14px 16px", borderRadius: 9, borderLeft: "4px solid" },
  notifBody: { flex: 1 },
  notifTitle: { fontSize: 12, fontWeight: 700, marginBottom: 2 },
  notifMsg: { fontSize: 11, lineHeight: 1.5 },
  closeBtn: { fontSize: 18, color: "#9ca3af", cursor: "pointer", background: "none", border: "none", lineHeight: 1, padding: "0 2px", flexShrink: 0 },
  emptyMsg: { fontSize: 12, color: "#9ca3af", textAlign: "center", marginTop: 20 },
};
