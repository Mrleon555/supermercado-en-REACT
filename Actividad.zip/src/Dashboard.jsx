import { useState } from "react";


const IconHome = () => (
  <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
  </svg>
);
const IconOrden = () => (
  <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
  </svg>
);
const IconInventario = () => (
  <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
  </svg>
);
const IconEmpleados = () => (
  <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0" />
  </svg>
);
const IconReportes = () => (
  <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
  </svg>
);
const IconAjustes = () => (
  <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);
const IconPerfil = () => (
  <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <circle cx="12" cy="8" r="4" /><path strokeLinecap="round" d="M4 20c0-4 3.6-7 8-7s8 3 8 7" />
  </svg>
);
const empleadosData = [
  { nombre: "Liseth", horas: 24 },
  { nombre: "Oscar", horas: 29 },
  { nombre: "Kevin", horas: 21 },
  { nombre: "Santiago", horas: 25 },
  { nombre: "Valeria", horas: 22 },
];
const ventasSemanales = [
  { dia: "Lun", monto: 3.1 },
  { dia: "Mar", monto: 3.4 },
  { dia: "Mié", monto: 3.6 },
  { dia: "Jue", monto: 2.3 },
  { dia: "Vie", monto: 3.0 },
  { dia: "Sáb", monto: 4.2 },
  { dia: "Dom", monto: 4.8 },
];
const navItems = [
  { label: "Inicio", icon: <IconHome />, key: "inicio" },
  { label: "Orden", icon: <IconOrden />, key: "orden" },
  { label: "Inventario", icon: <IconInventario />, key: "inventario" },
  { label: "Empleados", icon: <IconEmpleados />, key: "empleados" },
  { label: "Reportes", icon: <IconReportes />, key: "reportes" },
];
function BarChart({ datos, labelKey, valueKey, color, titulo, unidad = "" }) {
  const maxVal = Math.max(...datos.map((d) => d[valueKey]));

  return (
    <div style={styles.card}>
      <p style={styles.cardTitle}>{titulo}</p>
      <div style={styles.barsContainer}>
        {datos.map((d) => (
          <div key={d[labelKey]} style={styles.barWrap}>
            <span style={styles.barValue}>{d[valueKey]}{unidad}</span>
            <div
              style={{
                ...styles.bar,
                height: `${(d[valueKey] / maxVal) * 100}%`,
                backgroundColor: color,
              }}
            />
            <span style={styles.barLabel}>{d[labelKey]}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
function MetricCard({ titulo, valor, porcentaje, color, nota }) {
  return (
    <div style={styles.card}>
      <p style={styles.metricLabel}>{titulo}</p>
      <p style={styles.metricValue}>{valor}</p>
      <p style={styles.progressNote}>Punto de equilibrio diario</p>
      <div style={styles.progressBar}>
        <div
          style={{
            ...styles.progressFill,
            width: `${porcentaje}%`,
            backgroundColor: color,
          }}
        />
      </div>
      <div style={styles.progressLabels}>
        <span style={styles.progressTick}>0%</span>
        <span style={styles.progressTick}>{porcentaje}%</span>
        <span style={styles.progressTick}>100%</span>
      </div>
      {nota && <p style={styles.progressNoteItalic}>{nota}</p>}
    </div>
  );
}
export default function Dashboard() {
  const [activeNav, setActiveNav] = useState("inicio");

  return (
    <div style={styles.app}>
      {/* ── Sidebar ── */}
      <aside style={styles.sidebar}>
        <div style={styles.sidebarLogo}>
          <p style={styles.logoSub}>Sistema</p>
<p style={styles.logoTitle}>Supermercado</p>
        </div>

        <nav style={styles.navSection}>
          {navItems.map((item) => (
            <button
              key={item.key}
              onClick={() => setActiveNav(item.key)}
              style={{
                ...styles.navItem,
                ...(activeNav === item.key ? styles.navItemActive : {}),
              }}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </nav>

        <div style={styles.sidebarBottom}>
          <button style={styles.navItem}><IconAjustes /> Ajustes</button>
          <button style={styles.navItem}><IconPerfil /> Perfil</button>
        </div>
      </aside>
      <main style={styles.main}>
        <div style={styles.pageHeader}>
          <p style={styles.pageSub}>Inicio</p>
          <h1 style={styles.pageTitle}>Panel Resumen</h1>
        </div>
        <div style={styles.grid2}>
          <BarChart
            datos={empleadosData}
            labelKey="nombre"
            valueKey="horas"
            color="#3b82f6"
            titulo="Horas de trabajo reportadas (octubre)"
          />
          <BarChart
            datos={ventasSemanales}
            labelKey="dia"
            valueKey="monto"
            color="#14b8a6"
            titulo="Ventas últimos 7 días (millones COP)"
          />
        </div>

        <div style={styles.grid2}>
          <MetricCard
            titulo="Total ventas reportadas del 18 Noviembre"
            valor="$1,152,000"
            porcentaje={82}
            color="#3b82f6"
          />
          <MetricCard
            titulo="Ventas reportadas mes octubre"
            valor="$22,032,000"
            porcentaje={65}
            color="#14b8a6"
            nota="Del 01 al 16 de octubre"
          />
        </div>
      </main>
    </div>
  );
}
const styles = {
  app: {
    display: "flex",
    height: "100vh",
    background: "#f0f2f5",
    fontFamily: "'Segoe UI', sans-serif",
    fontSize: 13,
  },
  sidebar: {
    width: 170,
    background: "#1a2332",
    color: "#fff",
    display: "flex",
    flexDirection: "column",
    flexShrink: 0,
  },
  sidebarLogo: {
    padding: "18px 16px 14px",
    borderBottom: "1px solid #2d3f55",
  },
  logoSub: { fontSize: 11, color: "#7a9abe", textTransform: "uppercase", letterSpacing: 1, marginBottom: 2 },
  logoTitle: { fontSize: 15, fontWeight: 600, color: "#e8f0fe" },
  navSection: { display: "flex", flexDirection: "column", flex: 1, padding: "10px 0" },
  navItem: {
    display: "flex",
    alignItems: "center",
    gap: 10,
    padding: "9px 16px",
    cursor: "pointer",
    color: "#8fabc7",
    fontSize: 12.5,
    background: "none",
    border: "none",
    borderLeft: "3px solid transparent",
    textAlign: "left",
    width: "100%",
  },
  navItemActive: {
    background: "#1e3a5f",
    color: "#63b3ff",
    borderLeftColor: "#3b82f6",
  },
  sidebarBottom: { padding: "10px 0", borderTop: "1px solid #2d3f55" },
  main: { flex: 1, overflowY: "auto", padding: 20 },
  pageHeader: { marginBottom: 18 },
  pageSub: { fontSize: 11, color: "#6b7280", textTransform: "uppercase", letterSpacing: 1 },
  pageTitle: { fontSize: 22, fontWeight: 700, color: "#111827" },
  grid2: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 },
  card: {
    background: "#fff",
    borderRadius: 10,
    padding: 16,
    border: "0.5px solid #e5e7eb",
  },
  cardTitle: { fontSize: 11, color: "#6b7280", textTransform: "uppercase", letterSpacing: 0.8, marginBottom: 12, fontWeight: 600 },
  barsContainer: { display: "flex", alignItems: "flex-end", gap: 8, height: 100 },
  barWrap: { display: "flex", flexDirection: "column", alignItems: "center", gap: 4, flex: 1 },
  bar: { width: "100%", borderRadius: "4px 4px 0 0", transition: "opacity 0.2s" },
  barLabel: { fontSize: 9, color: "#9ca3af", textAlign: "center" },
  barValue: { fontSize: 9, color: "#374151", fontWeight: 600 },
  metricLabel: { fontSize: 11, color: "#6b7280", marginBottom: 6 },
  metricValue: { fontSize: 26, fontWeight: 700, color: "#111827", letterSpacing: -0.5, marginBottom: 12 },
  progressNote: { fontSize: 10, color: "#9ca3af", marginBottom: 6 },
  progressNoteItalic: { fontSize: 9, color: "#9ca3af", marginTop: 6, fontStyle: "italic" },
  progressBar: { height: 8, background: "#f3f4f6", borderRadius: 4, overflow: "hidden" },
  progressFill: { height: "100%", borderRadius: 4 },
  progressLabels: { display: "flex", justifyContent: "space-between", marginTop: 5 },
  progressTick: { fontSize: 9, color: "#9ca3af" },
};
