import Dashboard from './Dashboard'
import Login from './Login'
import Notificaciones from './Notificaciones'

function App() {
  return (
    <div>
      <Login />
      <Dashboard />
      <Notificaciones />
    </div>
  )
}

export default App